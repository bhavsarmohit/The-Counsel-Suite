<?php
$hn="localhost";
$db="counsel_suite";
$un="root";
$pw="";
?>